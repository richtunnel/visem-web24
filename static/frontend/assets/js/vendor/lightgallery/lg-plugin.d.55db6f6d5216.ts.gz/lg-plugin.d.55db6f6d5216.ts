import { LgQuery } from './lgQuery';
import { LightGallery } from './lightgallery';
export declare class LgPlugin {
    core: LightGallery;
    $LG: LgQuery;
    constructor(core: LightGallery, $LG: LgQuery);
}
