export interface PagerSettings {
    /**
     * Enable/Disable pager option
     */
    pager: boolean;
}
export declare const pagerSettings: PagerSettings;
