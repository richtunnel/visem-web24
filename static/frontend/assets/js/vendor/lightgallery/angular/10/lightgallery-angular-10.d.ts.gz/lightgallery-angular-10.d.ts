/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="lightgallery/angular/10" />
export * from './public-api';
//# sourceMappingURL=lightgallery-angular-10.d.ts.map