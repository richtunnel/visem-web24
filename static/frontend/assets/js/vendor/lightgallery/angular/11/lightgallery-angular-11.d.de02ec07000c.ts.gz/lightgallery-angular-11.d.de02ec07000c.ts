/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="lightgallery/angular/11" />
export * from './public-api';
//# sourceMappingURL=lightgallery-angular-11.d.ts.map