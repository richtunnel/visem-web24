import { LightGallerySettings } from './lg-settings';
import { LightGallery } from './lightgallery';
declare function lightGallery(el: HTMLElement, options?: LightGallerySettings): LightGallery;
export default lightGallery;
